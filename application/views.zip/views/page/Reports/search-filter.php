		        <?php
        $this->load->view('layout/header');
        $this->load->view('layout/container');
		?>
        <!-- BEGIN PAGE BASE CONTENT -->
                   <div class="row">
Search filter
                    </div>
                            <?php
        $this->load->view('layout/footer');   
        ?>
