		        <?php
        $this->load->view('layout/header');
        $this->load->view('layout/container');
		?>
        <!-- BEGIN PAGE BASE CONTENT -->
                   <div class="row">
Order
                    </div>
                            <?php
        $this->load->view('layout/footer');   
        ?>
