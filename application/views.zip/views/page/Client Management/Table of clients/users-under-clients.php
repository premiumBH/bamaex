		        <?php
        $this->load->view('layout/header');
        $this->load->view('layout/container');
		?>
        <!-- BEGIN PAGE BASE CONTENT -->
                   <div class="row">
Drill down list of users under clients
                    </div>
                            <?php
        $this->load->view('layout/footer');   
        ?>
