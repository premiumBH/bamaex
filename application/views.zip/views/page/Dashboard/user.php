		        <?php
        $this->load->view('layout/header');
        $this->load->view('layout/container');
		?>
        <!-- BEGIN PAGE BASE CONTENT -->

					<div class="row">
                    

					<div class="col-md-12">
                    
<a href="<?=CTRL?>user/create"><input value="Create User" class="btn green" type="button"></a><br /><br />
					     <div class="portlet box red">
                                 <div class="portlet-title">
                                    <div class="caption"><i class="fa fa-cogs"></i>Users Data</div>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                                        <a href="#portlet-config" data-toggle="modal" class="config" data-original-title="" title=""> </a>
                                        <a href="javascript:;" class="reload" data-original-title="" title=""> </a>
                                        <a href="javascript:;" class="remove" data-original-title="" title=""> </a>
                                    </div>
								</div>
                         </div>
					<div class="portlet-body">
                    

                                    <div class="table-responsive">
                                    
                                    <?
                                        ?>
                                            <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>S.No. </th>
                                                    <th>Full Name</th>
                                                    <th> Email</th>
                                                    <th> Mobile </th>
                                                    <th> User Level </th>
                                                    <th> Created On</th>
                                                </tr>
                                            </thead>
                                            <?php 
											if($result1['status'] = 'true')
									{
										if(isset($result1['users']))
										{
										foreach($result1['users'] AS $result)
										{
											echo '<tr>'
												.'<td><input type="hidden" value="'.$result->intUserId.'" name="id[]" />'.$result->intUserId.'</td>'
												.'<td>'.$result->varFirstName.' '.$result->varLastName.'</td>'
												.'<td>'.$result->varEmailId.'</td>'
												.'<td>'.$result->varMobileNo.'</td>'
												.'<td>'.$result->varUserTypeName.'</td>'
												.'<td>'.$result->dtCreated.'</td>'
												.'<td><a href="'.CTRL.'user/create?edit-id='.$result->intUserId.'"><input value="Edit" class="btn red" type="button"></a></td>'
											    .'</tr>';
										} 
									}
									}
                                            echo '</table>';
									 
									 ?>                                 
                                    </div>
                                
                                </div>
                                
                            </div>
                            
					</div>
                    
					
                            <?php
        $this->load->view('layout/footer');   
        ?>
