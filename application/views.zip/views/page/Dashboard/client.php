		        <?php
        $this->load->view('layout/header');
        $this->load->view('layout/container');
		?>
                    <!-- BEGIN PAGE BASE CONTENT -->
                   <div class="row">
				   <div class="col-md-12">
				  <h2> Clients</h2>
                      </div>
				   </div>
				 
					<div class="clearfix">&nbsp;</div>
					<div class="row">
					<div class="col-md-12">
					  <div class="portlet box red">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-cogs"></i>Clients Data</div>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse" data-original-title="" title=""> </a>
                                        <a href="#portlet-config" data-toggle="modal" class="config" data-original-title="" title=""> </a>
                                        <a href="javascript:;" class="reload" data-original-title="" title=""> </a>
                                        <a href="javascript:;" class="remove" data-original-title="" title=""> </a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="table-responsive">
                                    <?php
									/*
                                        $clients=$bam->get_table_array('client_table');

                                        if(!empty($clients))
                                        {
											*/
                                            echo '<table class="table">';
                                                echo '<thead><tr>';
                                                    echo '<td>ID</td>';
                                                    echo '<td>Full Name</td>';
                                                    echo '<td>Email</td>';
                                                    echo '<td>Mobile</td>';
                                                    echo '<td>Client Level</td>';
                                                    echo '<td>Date/Time</td>';
                                                    echo '<td>IS APPROVED</td>';
                                                    echo '<td></td>';
                                                echo '</tr></thead>';
/*
                                                $i=1;
                                            foreach($clients AS $c)
                                            {
                                                //echo json_encode($c);
                                                if($c['estatus']!=2)    //don't show deleted client
                                                {
                                                        echo '<tr>';
                                                        echo '<td>'.$i.'</td>';
                                                        echo '<td>'.ucwords($c['first_name'].' '.$c['last_name']).'</td>';
                                                        echo '<td>'.$c['email'].'</td>';
                                                        echo '<td>'.$c['mobile'].'</td>';
                                                        echo '<td>';
                                                            if($c['client_level_id']==0)
                                                                echo 'CLIENT';
                                                            else 
                                                            {
                                                                echo $bam->get_val_via_int('client_level','id',$c['client_level_id'],'client_level');
                                                            }
                                                        echo '</td>';
                                                        echo '<td>'.$c['edt'].'</td>';
                                                        echo '<td>';
                                                            if($c['is_approved']==1)
                                                                echo '<b>APPROVED</b>';
                                                            else if($c['is_approved']==0)
                                                            {
                                                                echo '<b>PENDING </b>';
                                                                echo '<a href="admin_h_get.php?action=APPROVE CLIENT&cid='.$c['id'].'">APPROVE</a>';
                                                                echo ' | ';
                                                                echo '<a href="admin_h_get.php?action=REJECT CLIENT&cid='.$c['id'].'">REJECT</a>';
                                                            }
                                                            else if($c['is_approved']==2)
                                                                echo '<b>REJECTED</b>';
                                                        echo '</td>';

                                                        echo '<td><a href="admin_h_get.php?action=DELETE CLIENT&cid='.$bam->encode($c['id']).'">Delete</a></td>';
                                                    echo '</tr>';
                                                    $i++;
                                                }
                                            } */
                                            echo '</table>';
                                       /* }
                                        else
                                        echo '<p>No client found.</p>';
                                   */ ?>
                                    </div>
                                </div>
                            </div>
				 
					
					</div>
					
					</div>



                    <!-- END PAGE BASE CONTENT -->

                            <?php
        $this->load->view('layout/footer');   
        ?>
