		        <?php
        $this->load->view('layout/header');
        $this->load->view('layout/container');
		?>
        <!-- BEGIN PAGE BASE CONTENT -->
                   <div class="row">
Total prospectus
                    </div>
                            <?php
        $this->load->view('layout/footer');   
        ?>
